CLIENT_ID :
1088648390218-dciu193mb6t1kh2ggpgtc817qc3gso1h.apps.googleusercontent.com
CLIENT_SECRET:
ZJJ8Zd7JuTkXu6PHxulwgUeg

-----------------
http://localhost/?code=4/4QECTvfpRqt02JSmqr6ox9d71l8u8f35z_Gz6YEDGGnte0oxl1zRbfO_mKF7dQ_xO4kmpunEraXmUoYVp722tHU&scope=https://www.googleapis.com/auth/gmail.readonly